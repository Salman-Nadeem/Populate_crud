const express = require('express');
const path = require('path');
const methodOverride = require('method-override');
require('dotenv').config();
const cors = require('cors');

const app = express();

app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'public', 'views'));
app.use(cors())
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(methodOverride('_method'));

const { DbConnection } = require('./public/Config/Db');
const P_cat = require('./public/Routes/P_catR');
const Product = require('./public/Routes/ProductR');

DbConnection();

app.use('/cat', P_cat);
app.use('/', Product);


const PORT = process.env.PORT || 3000;

app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});
