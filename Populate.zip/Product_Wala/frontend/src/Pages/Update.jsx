import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { useParams, useNavigate } from 'react-router-dom'; // Use useNavigate instead of useHistory

const ProductUpdateForm = () => {
  const { id } = useParams();
  const navigate = useNavigate(); // Use navigate for redirection

  const [P_Name, setP_Name] = useState('');
  const [P_Price, setP_Price] = useState('');
  const [P_Category, setP_Category] = useState('');
  const [categoryList, setCategoryList] = useState([]);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  const getData = async () => {
    try {
      const response = await axios.get('http://localhost:5000/cat/');
      if (Array.isArray(response.data)) {
        setCategoryList(response.data);
      } else {
        setError('Invalid data format for categories');
      }
    } catch (error) {
      setError('Failed to fetch categories');
    }
  };

  useEffect(() => {
    getData();
  }, []);

  const getProductData = async () => {
    try {
      const response = await axios.get(`http://localhost:5000/${id}`);
      const product = response.data;
      if (product) {
        setP_Name(product.P_Name);
        setP_Price(product.P_Price);
        setP_Category(product.P_Category._id);
      } else {
        setError('Product not found');
      }
    } catch (err) {
      setError('Error fetching product details');
    }
  };

  useEffect(() => {
    getProductData();
  }, [id]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    const updatedProduct = { P_Name, P_Price, P_Category };

    try {
      const response = await axios.put(`http://localhost:5000/${id}`, updatedProduct);
      setSuccess('Product updated successfully');
      setError('');
      navigate('/Product'); // Redirect to homepage or product listing page after successful update
    } catch (err) {
      setError('Error updating product');
      setSuccess('');
    }
  };

  return (
    <div className="container mt-5">
      <h1 className="text-center mt-5">Update Product</h1>
      {error && <div className="alert alert-danger">{error}</div>}
      {success && <div className="alert alert-success">{success}</div>}
      <form className="mt-4" onSubmit={handleSubmit}>
        <div className="mb-3">
          <label htmlFor="P_Name" className="form-label">Product Name</label>
          <input
            type="text"
            className="form-control"
            id="P_Name"
            value={P_Name}
            onChange={(e) => setP_Name(e.target.value)}
          />
        </div>
        <div className="mb-3">
          <label htmlFor="P_Price" className="form-label">Price</label>
          <input
            type="number"
            className="form-control"
            id="P_Price"
            value={P_Price}
            onChange={(e) => setP_Price(e.target.value)}
          />
        </div>
        <div className="mb-3">
          <label htmlFor="P_Category" className="form-label">Category</label>
          <select
            id="P_Category"
            className="form-control"
            value={P_Category}
            onChange={(e) => setP_Category(e.target.value)}
          >
            <option value="">Select a category</option>
            {categoryList.length > 0 ? (
              categoryList.map((category) => (
                <option key={category._id} value={category._id}>
                  {category.P_Cat}
                </option>
              ))
            ) : (
              <option value="" disabled>No categories available</option>
            )}
          </select>
        </div>
        <button type="submit" className="btn btn-dark">Update</button>
      </form>
    </div>
  );
};

export default ProductUpdateForm;
