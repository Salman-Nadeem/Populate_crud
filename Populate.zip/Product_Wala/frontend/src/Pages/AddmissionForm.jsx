import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

const ProductForm = () => {
  const navigate = useNavigate();
  
  const [P_Name, setP_Name] = useState('');
  const [P_Price, setP_Price] = useState('');
  const [P_Category, setP_Category] = useState('');
  const [categoryList, setCategoryList] = useState([]);  
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  const getData = async () => {
    try {
      const response = await axios.get('http://localhost:5000/cat/');
      if (Array.isArray(response.data)) {
        setCategoryList(response.data);
      } else {
        setError('Invalid data format for categories');
      }
    } catch (error) {
      setError('Failed to fetch categories');
    }
  };

  useEffect(() => {
    getData();
  }, []);

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!P_Name || !P_Price || !P_Category) {
      setError('All fields are required');
      return;
    }

    const productData = { P_Name, P_Price, P_Category };

    try {
      const response = await axios.post('http://localhost:5000/', productData);
      setSuccess('Product added successfully');
      setError('');
      navigate('/Product');
    } catch (err) {
      setError(err.response ? err.response.data.message : 'Error adding product');
      setSuccess('');
    }
  };

  return (
    <div className="container mt-5">
      <h1 className="text-center mt-5">Add Product</h1>
      {error && <div className="alert alert-danger">{error}</div>}
      {success && <div className="alert alert-success">{success}</div>}
      <form className="mt-4" onSubmit={handleSubmit} method="post">
        <div className="mb-3">
          <label htmlFor="P_Name" className="form-label">Product Name</label>
          <input
            type="text"
            className="form-control"
            id="P_Name"
            value={P_Name}
            onChange={(e) => setP_Name(e.target.value)}
          />
        </div>
        <div className="mb-3">
          <label htmlFor="P_Price" className="form-label">Price</label>
          <input
            type="number"
            className="form-control"
            id="P_Price"
            value={P_Price}
            onChange={(e) => setP_Price(e.target.value)}
          />
        </div>
        <div className="mb-3">
          <label htmlFor="P_Category" className="form-label">Category</label>
          <select
            id="P_Category"
            className="form-control"
            value={P_Category}
            onChange={(e) => setP_Category(e.target.value)}
          >
            <option value="">Select a category</option>
            {categoryList.length > 0 ? (
              categoryList.map((category) => (
                <option key={category._id} value={category._id}>
                  {category.P_Cat}
                </option>
              ))
            ) : (
              <option value="" disabled>No categories available</option>
            )}
          </select>
        </div>
        <button type="submit" className="btn btn-dark">Submit</button>
      </form>
    </div>
  );
};

export default ProductForm;
