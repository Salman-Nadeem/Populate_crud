import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { Link } from 'react-router-dom';

const Product = () => {
  const [products, setProducts] = useState([]);
  const [error, setError] = useState('');

  const getData = async () => {
    try {
      const response = await axios.get('http://localhost:5000/');
      if (Array.isArray(response.data)) {
        setProducts(response.data);
      } else {
        setError('Invalid data format');
      }
    } catch (error) {
      setError('Failed to fetch data');
    }
  };

  useEffect(() => {
    getData();
  }, []);

  const deleteProduct = async (id) => {
    try {
      const response = await axios.delete(`http://localhost:5000/${id}`);
      if (response.data.success) {
        setProducts(products.filter(product => product._id !== id));
      }
    } catch (error) {
      setError('Failed to delete product');
    }
  };

  return (
    <div className="container mt-4">
      <h1 className="text-center mt-4">Show All Products</h1>

      {error && <div className="alert alert-danger">{error}</div>}

      <table className="table mt-4">
        <thead>
          <tr className="table-dark">
            <th>#</th>
            <th>Product Name</th>
            <th>Price</th>
            <th>Category</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
          {products.length > 0 ? (
            products.map((product, index) => (
              <tr key={product._id}>
                <th>{index + 1}</th>
                <td>{product.P_Name}</td>
                <td>{product.P_Price}</td>
                <td>{product.P_Category.P_Cat}</td>
                <td>
                  <Link to={`/update/${product._id}`} className="btn btn-primary btn-sm me-2">
                    Update
                  </Link>
                  <button 
                    className="btn btn-danger btn-sm"
                    onClick={() => deleteProduct(product._id)}
                  >
                    Delete
                  </button>
                </td>
              </tr>
            ))
          ) : (
            <tr>
              <td colSpan="5" className="text-center">No products available</td>
            </tr>
          )}
        </tbody>
      </table>
    </div>
  );
};

export default Product;
