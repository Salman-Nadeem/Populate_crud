import React from 'react'

import './Style.css';
import { BrowserRouter,Routes,Route } from 'react-router-dom';

import Navbar from './Component/Navbar'


import Product from './Pages/ProductList';
import ProductForm from './Pages/AddmissionForm';
import ProductUpdateForm from './Pages/Update';



const App = () => {
  return (
    <BrowserRouter>

    <Navbar/>

    <Routes>
      <Route path="/" element={<ProductForm/>}/>
      <Route path="/Product" element={<Product/>}/>
      <Route path="/update/:id" element={<ProductUpdateForm/>}/>

    </Routes>
    </BrowserRouter>
  )
}

export default App